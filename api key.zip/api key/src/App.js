
import React, { Suspense } from 'react'
import { Route, Routes } from 'react-router-dom'
const Home = React.lazy(() => import("./Components/View/Home"))
const Navbar = React.lazy(() => import("./Components/Global/Navbar/Navbar"))
const Footer = React.lazy(() => import("./Components/Global/Footer/Footer"))
const Blog = React.lazy(() => import("./Components/View/Blog/Blog"))
const Blog2 = React.lazy(() => import("./Components/View/Blog/Blog2"))
const AddBlog = React.lazy(() => import("./Components/View/AddBlog/AddBlog"))
const Appbar = React.lazy(() => import("./Components/Global/Navbar/Appbar"))

const App = () => {
  return (
    <Suspense fallback={<h1>Loading...</h1>}>
    <Navbar/>
    <Appbar/>
      <Routes>
        <Route path='/user/:name' element={<Home/>}/>
        <Route path='/blog' element={<Blog/>}/>
        <Route path='/blog2' element={<Blog2/>}/>
        <Route path='/add-blog' element={<AddBlog/>}/>
      </Routes>
      <Footer/>
    </Suspense>
  )
}

export default App

